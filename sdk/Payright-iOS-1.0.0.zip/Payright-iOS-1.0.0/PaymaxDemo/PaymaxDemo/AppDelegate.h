//
//  AppDelegate.h
//  PaymaxDemo
//
//  Created by William on 16/5/20.
//  Copyright © 2016年 顺维无限. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

