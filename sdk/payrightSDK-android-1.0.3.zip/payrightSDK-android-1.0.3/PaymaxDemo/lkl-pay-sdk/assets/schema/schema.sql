CREATE TABLE user(
  id INTEGER PRIMARY KEY AUTOINCREMENT, 
  userId TEXT,
  loginTime TEXT,
  openGesture TEXT,
  gesturePwd TEXT,
  imgUrl TEXT
);

